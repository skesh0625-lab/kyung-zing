// main app entry
import KyungZingShop from "../components/KyungZingShop";
export default function Home() {
  return <KyungZingShop />;
}
